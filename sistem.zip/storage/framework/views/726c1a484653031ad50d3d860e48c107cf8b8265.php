<?php $__env->startSection('icerik'); ?>

    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>İçerik Ekle</h5>
                </div>

                <div class="widget-content nopadding">
                    <?php echo Form::open(['route'=>'yazilar.store','method'=>'POST','class'=>'form-horizontal','files'=>'true']); ?>


                    <div class="control-group">
                        <label class="control-label">Kategori Seçin</label>
                        <div class="controls">
                            <select name="kategori" class="span11">

                                <?php $__currentLoopData = $kategoriler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($kategori->id); ?>"><?php echo e($kategori->kategori_baslik); ?></option>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">İçerik Başlık</label>
                        <div class="controls">
                            <input type="text" class="span11" name="baslik"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">İçerik Açıklama</label>
                        <div class="controls">
                            <textarea name="icerik" class="span11"></textarea>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">İçerik Resmi</label>
                        <div class="controls">
                            <input type="file" class="span11" name="resim"/>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">İçerik Ekle</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/adminkurumsal/tinymce/js/tinymce/tinymce.min.js"></script>
    <script>tinymce.init({ selector:'textarea' });</script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminkurumsal/template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>