<?php $__env->startComponent('mail::layout'); ?>
    
    <?php $__env->slot('header'); ?>
        <?php $__env->startComponent('mail::header', ['url' => config('app.url')]); ?>
            <?php echo e($gonder['siteadi']); ?>

        <?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>

    
    <table>
        <tr>
            <td>Şirket Adı :</td> <td><?php echo e($gonder['groupName']); ?></td>
        </tr>
        <tr>
            <td>Şirket Unvanı:</td> <td> <?php echo e($gonder['groupLabel']); ?></td>
        </tr>
        <tr>
            <td>Adresi:</td> <td> <?php echo e($gonder['groupAdress']); ?></td>
        </tr>
        <tr>
            <td>Web Sitesi: </td> <td><?php echo e($gonder['groupWebsite']); ?></td>
        </tr>
        <tr>
            <td>Ülke: </td> <td><?php echo e($gonder['groupCountry']); ?></td>
        </tr>
        <tr>
            <td>Kuruluş Yılı:</td> <td> <?php echo e($gonder['foundedYear']); ?></td>
        </tr>
        <tr>
            <td>Şirketin Kuruluş Türü: </td> <td><?php echo e($gonder['foundationType']); ?></td>
        </tr>
        <tr>
            <td>Vergi Dairesi:</td> <td> <?php echo e($gonder['groupTaxBranch']); ?></td>
        </tr>
        <tr>
            <td>Vergi Numarası:</td> <td> <?php echo e($gonder['groupTaxNo']); ?></td>
        </tr>
        <tr>
            <td>Ticari Sicil Numarası: </td> <td><?php echo e($gonder['groupSicilNo']); ?></td>
        </tr>
        <tr>
            <td>SGK Sicil Numarası: </td> <td><?php echo e($gonder['groupSGKNo']); ?></td>
        </tr>
        <tr>
            <td>Ödenmiş Sermaye:</td> <td> <?php echo e($gonder['paidCapital']); ?></td>
        </tr>
        <tr>
            <td>Şirketin Çoğunluk Hissesinin Kime Ait Olduğu: </td> <td><?php echo e($gonder['biggestShareName']); ?></td>
        </tr>
        <tr>
            <td>Çoğunluk Hissedarının Hise Oranı:</td> <td> <?php echo e($gonder['biggestSharePerc']); ?></td>
        </tr>
        <tr>
            <td>Yabancı Hissedar Var Mı?:</td> <td> <?php echo e($gonder['foreignPartner']); ?></td>
        </tr>
        <tr>
            <td>Son 3 Yıllık Ciro:</td> <td> <?php echo e($gonder['lastEndorsement']); ?></td>
        </tr>
        <tr>
            <td>Gelecek 3 Yıllık Ciro Beklentinizi Yıl ve Rakam Olacak Şekilde Belirtiniz:</td>
            <td><?php echo e($gonder['nextEndorsement']); ?></td>
        </tr>
        <tr>
            <td>Geçen Yıl Fatura Kestiğiniz Müşteri Sayısı: </td> <td><?php echo e($gonder['lastInvoice']); ?></td>
        </tr>
        <tr>
            <td>İEM VATAN'a Başvuru Yaptığınız Ürününüzün Satışından Son 1 Yıldır Gerçekleşen Ciro: </td>
            <td><?php echo e($gonder['lastYearRevenue']); ?></td>
        </tr>
        <tr>
            <td>Yatırım Arıyor Musunuz:</td> <td> <?php echo e($gonder['needInvestment']); ?></td>
        </tr>
        <tr>
            <td>En Yüksek Hisseye Sahip Yabancı Hissedarın Hisse Oranını Belirtiniz:</td>
            <td><?php echo e($gonder['biggestForeignSharePerc']); ?></td>
        </tr>

        <tr>
            <td>Adınız: </td> <td><?php echo e($gonder['groupContactName']); ?></td>
        </tr>
        <tr>
            <td>Soyadınız: </td> <td><?php echo e($gonder['groupContactLastName']); ?></td>
        </tr>
        <tr>
            <td>Telefon:</td> <td> <?php echo e($gonder['groupContactPhone']); ?></td>
        </tr>
        <tr>
            <td>E-Mail:</td> <td> <?php echo e($gonder['groupContactEmail']); ?></td>
        </tr>
        <tr>
            <td>İEM VATAN'a Sizin Dışınızda Başvuracak Kişi Sayısı : </td> <td><?php echo e($gonder['groupOtherCount']); ?></td>
        </tr>



        <tr>
            <td>Satış: </td> <td><?php echo e($gonder['competence1Count']); ?></td>
        </tr>
        <tr>
            <td>Pazarlama:</td> <td> <?php echo e($gonder['competence2Count']); ?></td>
        </tr>
        <tr>
            <td>Yazılım: </td> <td><?php echo e($gonder['competence3Count']); ?></td>
        </tr>
        <tr>
            <td>Tasarım:</td> <td> <?php echo e($gonder['competence4Count']); ?></td>
        </tr>
        <tr>
            <td>Üretim Planlama: </td> <td><?php echo e($gonder['competence5Count']); ?></td>
        </tr>
        <tr>
            <td>Muhasebe: </td> <td><?php echo e($gonder['competence6Count']); ?></td>
        </tr>
        <tr>
            <td>Stratejik Yönetim:</td> <td> <?php echo e($gonder['competence7Count']); ?></td>
        </tr>
        <tr>
            <td>Elektrik - Elektronik: </td> <td><?php echo e($gonder['competence8Count']); ?></td>
        </tr>
        <tr>
            <td>Mekanik:</td> <td> <?php echo e($gonder['competence9Count']); ?></td>
        </tr>
        <tr>
            <td>Diğer: </td> <td><?php echo e($gonder['competence10Count']); ?></td>
        </tr>


        <tr>
            <td>Kaç Tip Ürün: </td> <td><?php echo e($gonder['productCount']); ?></td>
        </tr>
        <tr>
            <td>Ana Ürünler:</td> <td> <?php echo e($gonder['productSummary']); ?></td>
        </tr>


        <tr>
            <td>Proje Teknolojisi:</td> <td> <?php echo e($gonder['projectTech']); ?></td>
        </tr>

        <tr>
            <td>Hangi Sektördesiniz?:</td> <td> <?php echo e($gonder['sector']); ?></td>
        </tr>
        <tr>
            <td>Hedeflenen Ana Müşteri Grubu:</td> <td> <?php echo e($gonder['targetGroupSummary']); ?></td>
        </tr>
        <tr>
            <td>Hedeflenen Ana Müşteri Grubu Sektörü: </td> <td><?php echo e($gonder['targetSector']); ?></td>
        </tr>
        <tr>
            <td>Müşteri Grubu Sektörünün İhtiyacını Gideren Kişi Ve Web Adresleri:</td> <td> <?php echo e($gonder['competitorWebsites']); ?></td>
        </tr>
        <tr>
            <td>Rakiplerinizden Sizi Ayıran Özellikler: </td> <td><?php echo e($gonder['competitorDifference']); ?></td>
        </tr>
        <tr>
            <td>Ürününüzü Nasıl Fiyatlandırıyorsunuz?: </td> <td><?php echo e($gonder['businessModel2']); ?></td>
        </tr>


        <tr>
            <td>Yatırım Aldınız Mı?: </td> <td><?php echo e($gonder['haveInvestment']); ?></td>
        </tr>
        <tr>
            <td>Patent Başvurunuz Var Mı?:</td> <td> <?php echo e($gonder['havePatent']); ?></td>
        </tr>



</table>
    
    <?php if(isset($subcopy)): ?>
        <?php $__env->slot('subcopy'); ?>
            <?php $__env->startComponent('mail::subcopy'); ?>
                <?php echo e($subcopy); ?>

            <?php echo $__env->renderComponent(); ?>
        <?php $__env->endSlot(); ?>
    <?php endif; ?>

    
    <?php $__env->slot('footer'); ?>
        <?php $__env->startComponent('mail::footer'); ?>
            <?php echo e($gonder['siteadi']); ?>

        <?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>





