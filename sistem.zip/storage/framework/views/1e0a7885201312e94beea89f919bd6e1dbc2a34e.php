<?php $__env->startSection('icerik'); ?>

    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Menü Ekle</h5>
                </div>

                <div class="widget-content nopadding">
                <div>
                  <strong>Etkinlik ve Duyuru Özel Link</strong> : <?php echo e($url); ?>/hizmetler
                  <br>
                  <strong>Birimler</strong> : <?php echo e($url); ?>/birimler
                  <br>
                  <strong>Proje Ekibi</strong> : <?php echo e($url); ?>/ekip
                 </div>
                    <?php echo Form::open(['route'=>'menuler.store','method'=>'POST','class'=>'form-horizontal',]); ?>


                    <div class="control-group">
                        <label class="control-label">Menü Başlık</label>
                        <div class="controls">
                            <input type="text" class="span11" name="menu_baslik"/>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">Menü Sayfası Seçin</label>
                        <div class="controls">
                            <select name="sayfa_id" class="span11">
                                <option value="0" selected>Özel Url</option>

                                <?php $__currentLoopData = $sayfalar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sayfa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($sayfa->id); ?>"><?php echo e($sayfa->sayfa_basligi); ?></option>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </select>


                        </div>
                    </div>


                    <div class="control-group">
                        <label class="control-label"> Özel Url</label>
                        <div class="controls">
                            <input  type="text" class="span11" name="ozel_url"/>

                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Menü Sıra</label>
                        <div class="controls">
                            <input type="number" value="0" class="span11" name="sira_no"/>
                            
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">Üst Menü</label>
                        <div class="controls">
                            <select id="menu_ust_id" name="menu_ust_id" class="span11">

                                <option value="0">Yok</option>
                                <?php $__currentLoopData = $menuler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($menu->id); ?>"><?php echo e($menu->menu_baslik); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </select>
                        </div>
                    </div>
                   
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success" >Menü Ekle</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/adminkurumsal/tinymce/js/tinymce/tinymce.min.js"></script>
    <script>tinymce.init({ selector:'textarea' });</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminkurumsal/template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>