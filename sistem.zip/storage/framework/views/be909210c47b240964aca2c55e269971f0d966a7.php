<?php $__env->startSection('icerik'); ?>
    <div style="float:right; margin: 15px 0 5px 0;"><a href="<?php echo e(route('sayfalar.create')); ?>" class="btn btn-success">Sayfa Ekle</a></div>
    <div style="clear:both;"></div>
    <div class="widget-box">
        <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>Sayfa Yönetimi</h5>
        </div>
        <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
                <thead>
                <tr>
                    <th>Sayfa Başlık</th>
                    <th>Sayfa Açıklama</th>
                    <th width="5%">Düzenle</th>
                    <th width="5%">Sil</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $sayfalar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sayfa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="gradeX">
                        <td><?php echo e($sayfa->sayfa_basligi); ?></td>
                        <td>

<?php echo str_limit(strip_tags($sayfa->sayfa_icerik),$limit=100,$end='...'); ?>


                        </td>

                        <td class="center"><a href="<?php echo e(route('sayfalar.edit', $sayfa->id)); ?>"class="btn btn-success btn-mini">Düzenle</a> </td>

                        <?php echo Form::model($sayfa,['route'=>['sayfalar.destroy',$sayfa->id],'method'=>'DELETE']); ?>

                        <td class="center">
                            <button type="submit" onclick="return window.confirm('Silmek istediğinize eminmisiniz?');" class="btn btn-danger btn-mini">Sil</button>
                        </td>

                        <?php echo Form::close(); ?>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/adminkurumsal/css/uniform.min.css" />
    <link rel="stylesheet" href="/adminkurumsal/css/select2.css" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/adminkurumsal/js/excanvas.min.js"></script>
    <script src="/adminkurumsal/js/jquery.min.js"></script>
    <script src="/adminkurumsal/js/jquery.ui.custom.js"></script>
    <script src="/adminkurumsal/js/bootstrap.min.js"></script>

    <script src="/adminkurumsal/js/jquery.dataTables.min.js"></script>
    <script src="/adminkurumsal/js/matrix.tables.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminkurumsal/template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>