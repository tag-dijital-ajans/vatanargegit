<?php $__env->startSection('icerik'); ?>


    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5> Birim Düzenle : <?php echo e($hizmet->hizmet_basligi); ?></h5>
                </div>



                <div class="widget-content nopadding">
                    <?php echo Form::model($hizmet,(['route'=>['hizmetler.update',$hizmet->id],'method'=>'PUT','class'=>'form-horizontal','files'=>'true'])); ?>





                    <div class="control-group">
                        <label class="control-label"> Birim Başlık</label>
                        <div class="controls">
                            <input type="text" class="span11" name="hizmet_basligi" value="<?php echo e($hizmet->hizmet_basligi); ?>"  />
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label"> Birim İçerik</label>
                        <div class="controls">
                            <textarea name="hizmet_icerik" class="span11"><?php echo $hizmet->hizmet_icerik; ?></textarea>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label"> Birim Görseli</label>
                        <div class="controls">
                            <input type="file" name="hizmet_one_cikan_foto"  class="span11"  />
                        </div>
                        <div><img width="300px" src="/<?php echo e($hizmet->hizmet_one_cikan_foto); ?>"></div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Birim Güncelle</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script src="/adminkurumsal/tinymce/js/tinymce/tinymce.min.js"></script>
    <script>tinymce.init({ selector:'textarea' });</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminkurumsal/template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>