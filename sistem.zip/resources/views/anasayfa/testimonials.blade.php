@extends ('anasayfa.template')

@section('icerik')

    <!-- Testimonials -->
    <section class="parallax100 kit-overlay2 p-t-92 p-b-90" style="background-image: url(/anasayfa/images/bg-02.jpg);">
        <div class="container">
            <!-- Title section -->
            <div class="flex-col-c-c p-b-50">
                <h3 class="t1-b-1 cl-0 txt-center m-b-11">
                    Testimonials
                </h3>

                <div class="size-a-2 bg-0"></div>
            </div>

            <!-- Slick1 -->
            <div class="wrap-slick1">
                <div class="slide-slick">
                    <div class="item-slick p-rl-15 wrap-block3">
                        <div class="block3 d-flex">
                            <div class="block3-content d-flex">
                                <div class="block3-pic wrap-pic-w">
                                    <img src="/anasayfa/images/ava-01.jpg" alt="IMG">
                                </div>

                                <div class="block3-text d-flex w-full-sr575">
									<span class="block3-text-child t1-m-1 text-uppercase cl-0 p-b-4">
										Marie Crawford
									</span>

                                    <span class="block3-text-child t1-s-3 cl-14 p-b-9">
										Wall Street Combany
									</span>

                                    <p class="block3-text-child t1-s-2 cl-13">
                                        The point of using Lorem Ipsum is that it has a normal distr bution of letters, as opposed to using Many desktop publis shing packages and web page Ipsum.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="item-slick p-rl-15 wrap-block3">
                        <div class="block3 d-flex">
                            <div class="block3-content d-flex">
                                <div class="block3-pic wrap-pic-w">
                                    <img src="/anasayfa/images/ava-02.jpg" alt="IMG">
                                </div>

                                <div class="block3-text d-flex w-full-sr575">
									<span class="block3-text-child t1-m-1 text-uppercase cl-0 p-b-4">
										Jerry Alexander
									</span>

                                    <span class="block3-text-child t1-s-3 cl-14 p-b-9">
										Wall Street Combany
									</span>

                                    <p class="block3-text-child t1-s-2 cl-13">
                                        The point of using Lorem Ipsum is that it has a normal distr bution of letters, as opposed to using Many desktop publis shing packages and web page Ipsum.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="item-slick p-rl-15 wrap-block3">
                        <div class="block3 d-flex">
                            <div class="block3-content d-flex">
                                <div class="block3-pic wrap-pic-w">
                                    <img src="/anasayfa/images/ava-01.jpg" alt="IMG">
                                </div>

                                <div class="block3-text d-flex w-full-sr575">
									<span class="block3-text-child t1-m-1 text-uppercase cl-0 p-b-4">
										Marie Crawford
									</span>

                                    <span class="block3-text-child t1-s-3 cl-14 p-b-9">
										Wall Street Combany
									</span>

                                    <p class="block3-text-child t1-s-2 cl-13">
                                        The point of using Lorem Ipsum is that it has a normal distr bution of letters, as opposed to using Many desktop publis shing packages and web page Ipsum.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="item-slick p-rl-15 wrap-block3">
                        <div class="block3 d-flex">
                            <div class="block3-content d-flex">
                                <div class="block3-pic wrap-pic-w">
                                    <img src="/anasayfa/images/ava-02.jpg" alt="IMG">
                                </div>

                                <div class="block3-text d-flex w-full-sr575">
									<span class="block3-text-child t1-m-1 text-uppercase cl-0 p-b-4">
										Jerry Alexander
									</span>

                                    <span class="block3-text-child t1-s-3 cl-14 p-b-9">
										Wall Street Combany
									</span>

                                    <p class="block3-text-child t1-s-2 cl-13">
                                        The point of using Lorem Ipsum is that it has a normal distr bution of letters, as opposed to using Many desktop publis shing packages and web page Ipsum.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="item-slick p-rl-15 wrap-block3">
                        <div class="block3 d-flex">
                            <div class="block3-content d-flex">
                                <div class="block3-pic wrap-pic-w">
                                    <img src="/anasayfa/images/ava-01.jpg" alt="IMG">
                                </div>

                                <div class="block3-text d-flex w-full-sr575">
									<span class="block3-text-child t1-m-1 text-uppercase cl-0 p-b-4">
										Marie Crawford
									</span>

                                    <span class="block3-text-child t1-s-3 cl-14 p-b-9">
										Wall Street Combany
									</span>

                                    <p class="block3-text-child t1-s-2 cl-13">
                                        The point of using Lorem Ipsum is that it has a normal distr bution of letters, as opposed to using Many desktop publis shing packages and web page Ipsum.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="item-slick p-rl-15 wrap-block3">
                        <div class="block3 d-flex">
                            <div class="block3-content d-flex">
                                <div class="block3-pic wrap-pic-w">
                                    <img src="/anasayfa/images/ava-02.jpg" alt="IMG">
                                </div>

                                <div class="block3-text d-flex w-full-sr575">
									<span class="block3-text-child t1-m-1 text-uppercase cl-0 p-b-4">
										Jerry Alexander
									</span>

                                    <span class="block3-text-child t1-s-3 cl-14 p-b-9">
										Wall Street Combany
									</span>

                                    <p class="block3-text-child t1-s-2 cl-13">
                                        The point of using Lorem Ipsum is that it has a normal distr bution of letters, as opposed to using Many desktop publis shing packages and web page Ipsum.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="wrap-dot-slick p-t-70"></div>
            </div>
        </div>
    </section>

@endsection

@section('css')

@endsection

@section('js')

@endsection