<?php $__env->startSection('icerik'); ?>


    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Site Ayarları</h5>
                </div>
                <div class="widget-content nopadding">
                   <?php echo Form::model($ayarlar,['route'=>['ayarlar.update',1],'method'=>'PUT','files'=>'true','class'=>'form-horizontal']); ?>



                   




                        <div class="control-group">
                            <label class="control-label"> Site Başlık</label>
                            <div class="controls">
                                <input type="text" class="span11" name="site_adi" value="<?php echo e($ayarlar->site_adi); ?>" />
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Firma Adresi</label>
                            <div class="controls">
                                <input type="text" class="span11" name="firma_adres" value="<?php echo e($ayarlar->firma_adres); ?>" />
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label"> E-Mail Adresi</label>
                            <div class="controls">
                                <input type="email" class="span11" name="email" value="<?php echo e($ayarlar->email); ?>"  />
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Ana Logo</label>
                            <div class="controls">
                                <input type="file" name="logo" class="span11"  />


                                <span class="help-block">jpeg,png,jpg,gif,svg|max:512kb</span>

                                <div>
                                <img width="200px" src="/<?php echo e($ayarlar->logo); ?>">

                                </div><button type="submit" class="btn btn-success">Logo Güncelle</button>
                            </div>

                        </div>
                        <div class="control-group">
                            <label class="control-label">Footer Logo</label>
                            <div class="controls">
                                <input type="file" name="footerlogo" class="span11"  />


                                <span class="help-block">Max.500 kb</span>

                                <div>
                                <img width="200px" src="/<?php echo e($ayarlar->footerlogo); ?>">
                                <div>jpeg,png,jpg,gif,svg|max:512kb</div>

                                </div><button type="submit" class="btn btn-success">Logo Güncelle</button>
                            </div>

                        </div>
                        <div class="control-group">
                             <label class="control-label">Favicon</label>
                                <div class="controls">
                                   <input type="file" name="favicon" class="span11" />

                                   <span class="help-block">Max 40x40 (px) ve 100 kb</span>
                                   <div>
                                    <img width="40px" height="40px" src="/<?php echo e($ayarlar->favicon); ?>">
                                   </div>
                                    <button type="submit" class="btn btn-success">Favicon Güncelle</button>
                                   </div>
                                   </div>
                        <div class="control-group">
                            <label class="control-label"> Telefon</label> 
                            <div class="controls">
                                <input type="number" name="telefon" value="<?php echo e($ayarlar->telefon); ?>" class="span11" />
                                <span class="help-block">Örn(02566125960)</span>
                             </div>
                        </div>
                     <span><strong>Metin Ayarlar</strong></span>
                    <div class="control-group">
                        <label class="control-label">Footer Logo Altı Yazı</label>
                        <div class="controls">
                            <textarea class="span11" placeholder="Google Tag Manager <head> kodu" name="tag_manager_kod"><?php echo e($ayarlar->tag_manager_kod); ?></textarea>
                            
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label"> Google Map </label>
                        <div class="controls">
                             <input type="text" class="span11" value="<?php echo e($ayarlar->tag_manager_script); ?>" placeholder="Google Tag Manager <body> kodu" name="google_map"><?php echo $ayarlar->tag_manager_script; ?></input>

                         </div>
                    </div>




                    <div class="control-group">
                        <label class="control-label"> Footer Yazısı</label>
                        <div class="controls">
                            <input type="text" class="span11" name="footer_yazisi" value="<?php echo e($ayarlar->footer_yazisi); ?>" />
                            <span class="help-block">Html Kullanmayınız</span>
                        </div>
                    </div>
                    <span><strong>Sosyal Medya Hesapları - Full Profil Linklerini Giriniz</strong></span>
                    <div class="control-group">
                         <label class="control-label">Facebook</label>
                         <div class="controls">
                         <input type="text" class="span11" placeholder="https://facebook.com/kullaniciadi" name="facebook" value="<?php echo e($ayarlar->facebook); ?>" />

                         </div>
                     </div>
                     <div class="control-group">
                         <label class="control-label">Instagram</label>
                         <div class="controls">
                         <input type="text" class="span11" placeholder="https://instagram.com/kullaniciadi" name="instagram" value="<?php echo e($ayarlar->instagram); ?>" />

                         </div>
                     </div>
                     <div class="control-group">
                         <label class="control-label">Twitter</label>
                         <div class="controls">
                         <input type="text" class="span11" placeholder="https://twitter.com/kullaniciadi" name="twitter" value="<?php echo e($ayarlar->twitter); ?>" />

                         </div>
                     </div>
                     <div class="control-group">
                         <label class="control-label">LinkedIn</label>
                         <div class="controls">
                         <input type="text" class="span11" placeholder="Linkedin Profil Adresi" name="linkedin" value="<?php echo e($ayarlar->linkedin); ?>" />

                         </div>
                     </div>
                        <div class="control-group">
                         <label class="control-label">Pinterest</label>
                         <div class="controls">
                         <input type="text" class="span11" name="pinterest" value="<?php echo e($ayarlar->pinterest); ?>" />

                         </div>
                     </div>
                        <div class="control-group">
                         <label class="control-label">Youtube</label>
                         <div class="controls">
                         <input type="text" class="span11" name="youtube" placeholder="Kanal Adresi" value="<?php echo e($ayarlar->youtube); ?>" />

                         </div>
                     </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-success">Güncelle</button>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminkurumsal/template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>