
<!-- Birimler -->
<section class="bg-12 p-t-92 p-b-60">
    <div class="container">
        <!-- Title section -->
        <div class="flex-col-c-c p-b-50">
            <h3 class="t1-b-1 cl-3 txt-center m-b-11">
                Birimler
            </h3>

            <div class="size-a-2 bg-3"></div>
        </div>

        <!--  -->
        <div class="row justify-content-center">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-10 col-md-8 col-lg-4 p-b-40">
                <!-- Block2 -->
                <div class="block2 bg-img2" style="background-image: url('/<?php echo e($service->hizmet_one_cikan_foto); ?>');">
                    <div class="block2-content trans-04">
                        <h4 class="block2-title t1-m-1 cl-0 flex-s-c trans-04">
                            <?php echo e($service->hizmet_basligi); ?>

                        </h4>

                        

                        <a href="/hizmet/<?php echo e($service->id); ?>/<?php echo e($service->slug); ?>" class="d-inline-flex flex-c-c size-a-1 p-rl-15 t1-s-2 text-uppercase cl-6 bg-0 hov-btn3 trans-02">
                            Detaylar
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>
</section>



<!--Birimler -->




    <!-- Eski Birimler -->
    

<!-- Video -->
	<section class="bg-0 p-t-20 p-b-20">
		<div class="container">

			<div class="size-w-1 m-rl-auto">
				<iframe width="600" height="315" src="https://www.youtube.com/embed/<?php echo e($anasayfaayar->anasayfavideo); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>
		</div>
	</section>