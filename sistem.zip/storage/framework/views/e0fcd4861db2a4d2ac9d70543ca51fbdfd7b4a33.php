

    <!-- Footer -->
    <footer>
        <div class="parallax100 kit-overlay1 p-t-35 p-b-10" style="background-image: url(/anasayfa/images/bg-03.jpg);">
            <div class="container">
                <div class="row justify-content-center justify-content-md-start">
                    <div class="col-sm-8 col-md-4 col-lg-3 p-b-20">
                        <div class="size-h-1 flex-s-e p-b-6 m-b-18">
                            <a href="#">
                                <img class="max-s-full" src="/<?php echo e($ayar->footerlogo); ?>" width="140"height="75" alt="IMG">
                            </a>
                        </div>

                        <div>
                            <p class="t1-s-2 cl-13 p-b-17">
                                   <?php echo e($ayar->tag_manager_kod); ?>

                            </p>

                            <div class="flex-wr-s-c p-t-10">
                                <?php if($ayar->facebook): ?>
                                <a href="<?php echo e($ayar->facebook); ?>" class="flex-c-c size-a-7 borad-50per bg-11 fs-16 cl-0 hov-btn2 trans-02 m-r-10">
                                    <i class="fa fa-facebook"></i>
                                </a>
                                <?php endif; ?>
                                <?php if($ayar->twitter): ?>
                                <a href="<?php echo e($ayar->twitter); ?>" class="flex-c-c size-a-7 borad-50per bg-11 fs-16 cl-0 hov-btn2 trans-02 m-r-10">
                                    <i class="fa fa-twitter"></i>
                                </a>
                                <?php endif; ?>
                                <?php if($ayar->pinterest): ?>
                                <a href="<?php echo e($ayar->pinterest); ?>" class="flex-c-c size-a-7 borad-50per bg-11 fs-16 cl-0 hov-btn2 trans-02 m-r-10">
                                    <i class="fa fa-pinterest"></i>
                                </a>
                                <?php endif; ?>
                                <?php if($ayar->instagram): ?>
                                <a href="<?php echo e($ayar->instagram); ?>" class="flex-c-c size-a-7 borad-50per bg-11 fs-16 cl-0 hov-btn2 trans-02 m-r-10">
                                    <i class="fa fa-instagram"></i>
                                </a>
                                <?php endif; ?>
                                <?php if($ayar->linkedin): ?>
                                <a href="<?php echo e($ayar->linkedin); ?>" class="flex-c-c size-a-7 borad-50per bg-11 fs-16 cl-0 hov-btn2 trans-02 m-r-10">
                                    <i class="fa fa-linkedin"></i>
                                </a>
                                <?php endif; ?>
                                <?php if($ayar->youtube): ?>
                                <a href="<?php echo e($ayar->youtube); ?>" class="flex-c-c size-a-7 borad-50per bg-11 fs-16 cl-0 hov-btn2 trans-02 m-r-10">
                                     <i class="fa fa-youtube"></i>
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-8 col-md-4 col-lg-3 p-b-20">
                        <div class="size-h-1 flex-s-e m-b-18">
                            <h4 class="t1-m-3 text-uppercase cl-0">
                                İletişim
                            </h4>
                        </div>

                        <ul>
                            <li class="flex-wr-s-s t1-s-2 cl-13 p-b-9">
								<span class="size-w-3">
									<i class="fa fa-home" aria-hidden="true"></i>
								</span>

                                <span class="size-w-4">
									<?php echo e($ayar->firma_adres); ?>

								</span>
                            </li>

                            <li class="flex-wr-s-s t1-s-2 cl-13 p-b-9">
								<span class="size-w-3">
									<i class="fa fa-envelope-o" aria-hidden="true"></i>
								</span>

                                <span class="size-w-4">
									<?php echo e($ayar->email); ?>

								</span>
                            </li>

                            <li class="flex-wr-s-s t1-s-2 cl-13 p-b-9">
								<span class="size-w-3">
									<i class="fa fa-phone" aria-hidden="true"></i>
								</span>

                                <span class="size-w-4">
									<?php echo e($ayar->telefon); ?>

									<br>
									05389227347
								</span>
                            </li>
                        </ul>
                    </div>

                    <div class="col-sm-8 col-md-4 col-lg-3 p-b-20">
                        <div class="size-h-1 flex-s-e m-b-18">
                            <h4 class="t1-m-3 text-uppercase cl-0">
                               Linkler
                            </h4>
                        </div>

                        <div class="flex-wr-s-s">

                            <ul class="w-50">

                                
                                <li class="kit-list1 p-b-9">
                                    <a href="<?php echo e(route('anasayfa')); ?>" class="t1-s-2 cl-13 hov-link2 trans-02">
                                       Anasayfa</a>
                                </li>
                                <li class="kit-list1 p-b-9">
                                    <a href="<?php echo e(route('hizmetleri.goster')); ?>" class="t1-s-2 cl-13 hov-link2 trans-02">
                                        Haberler</a>
                                </li>
                                <li class="kit-list1 p-b-9">
                                 <a href="<?php echo e(route('hizmetleri.goster')); ?>" class="t1-s-2 cl-13 hov-link2 trans-02">
                                    Hizmetler</a>
                                </li>
                                <li class="kit-list1 p-b-9">
                                                                 <a href="<?php echo e(route('ekip.sayfasi')); ?>" class="t1-s-2 cl-13 hov-link2 trans-02">
                                                                    Proje Ekibi</a>
                                                                </li>
                               <li class="kit-list1 p-b-9">
                               <a href="<?php echo e(route('iletisim.formu')); ?>" class="t1-s-2 cl-13 hov-link2 trans-02">
                                   İletişim</a>
                               </li>

                            </ul>



                        </div>
                    </div>

                    <div class="col-sm-8 col-md-6 col-lg-3 p-b-20">
                        <div class="size-h-1 flex-s-e m-b-18">
                            <h4 class="t1-m-3 text-uppercase cl-0">
                                Son Haberler
                            </h4>
                        </div>

                        <div class="flex-wr-s-s p-t-6 gallery-mp">
                            <?php $__currentLoopData = $footericerikler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footericerik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <a href="/haber/<?php echo e($footericerik->id); ?>/<?php echo e($footericerik->slug); ?>" class="d-block size-a-8 bg-img1 hov-overlay1 m-r-10 m-b-20" style="background-image: url(/<?php echo e($footericerik->resim); ?>);"></a>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<section class="bg-0 p-t-20 p-b-20">


        <div class="row justify-content-center">

            <?php $__currentLoopData = $kurumlogolar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kurum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-4 col-lg-2 flex-c-c p-b-60">
                <a href="<?php echo e($kurum->link); ?>" target="_blank">
                    <img class="trans-02 max-s-full" src="<?php echo e($kurum->logo); ?>" width="200"  alt="<?php echo e($kurum->kurumadi); ?>">
                </a>
            </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

</section>
        <div class="bg-10">
            <div class="container txt-center p-tb-15">
				<span class="t1-s-2 cl-14">
					Copyright @ 2019 Designed by Tag Ajans. Tüm Hakları Saklıdır.
				</span>
            </div>
        </div>
    </footer>
