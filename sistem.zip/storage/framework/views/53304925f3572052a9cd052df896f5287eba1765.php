<!-- Header desktop -->
<nav class="container-header-desktop">
    <div class="top-bar">
        <div class="content-topbar container flex-sb-c h-full">
            <div class="size-w-0 flex-wr-s-c">
                <div class="t1-s-1 cl-13 m-r-50">
							<span class="fs-16 m-r-6">
								<i class="fa fa-home" aria-hidden="true"></i>
							</span>
                    <span><?php echo e($ayar->firma_adres); ?></span>
                </div>

                <div class="t1-s-1 cl-13 m-r-50">
							<span class="fs-16 m-r-6">
								<i class="fa fa-phone" aria-hidden="true"></i>
							</span>
                    <span><a class="t1-s-2 cl-13 hov-link2 trans-02" href="tel:<?php echo e($ayar->telefon); ?>"><?php echo e($ayar->telefon); ?></a></span>
                </div>


            </div>

            <div class="text-nowrap">
                <?php if($ayar->facebook): ?>
                <a href="<?php echo e($ayar->facebook); ?>" class="fs-16 cl-13 hov-link2 trans-02 m-l-15">
                    <i class="fa fa-facebook-official"></i>
                </a>
                <?php endif; ?>
                <?php if($ayar->twitter): ?>
                <a href="<?php echo e($ayar->twitter); ?>" class="fs-16 cl-13 hov-link2 trans-02 m-l-15">
                    <i class="fa fa-twitter"></i>
                </a>
                <?php endif; ?>
                <?php if($ayar->pinterest): ?>
                <a href="<?php echo e($ayar->pinterest); ?>" class="fs-16 cl-13 hov-link2 trans-02 m-l-15">
                    <i class="fa fa-pinterest"></i>
                </a>
                <?php endif; ?>
                <?php if($ayar->instagram): ?>
                <a href="<?php echo e($ayar->instagram); ?>" class="fs-16 cl-13 hov-link2 trans-02 m-l-15">
                    <i class="fa fa-instagram"></i>
                </a>
                <?php endif; ?>
                <?php if($ayar->linkedin): ?>
                <a href="<?php echo e($ayar->linkedin); ?>" class="fs-16 cl-13 hov-link2 trans-02 m-l-15">
                    <i class="fa fa-linkedin"></i>
                </a>
                <?php endif; ?>
                <?php if($ayar->youtube): ?>
                 <a href="<?php echo e($ayar->youtube); ?>" class="fs-16 cl-13 hov-link2 trans-02 m-l-15">
                                    <i class="fa fa-youtube"></i>
                                </a>
                                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="wrap-menu-desktop">
        <div class="limiter-menu-desktop container">
            <!-- Logo desktop -->
            <div class="logo" >
                <a href="/"><img  src="/<?php echo e($ayar->logo); ?>" alt="LOGO" ></a>
            </div>

            <!-- Menu desktop -->
            <div class="menu-desktop">
                <ul class="main-menu respon-sub-menu">
                    <?php $__currentLoopData = $menuler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>

                            <?php if($menu->sayfa_id == 0): ?>
                        <a href="<?php echo e($menu->ozel_url); ?>"><?php echo e($menu->menu_baslik); ?></a>

                            <?php else: ?>
                        <a href="/sayfa/<?php echo e($menu->sayfa_id); ?>/<?php echo e($menu->slug); ?>"><?php echo e($menu->menu_baslik); ?></a>
                            <?php endif; ?>
                        <?php if($menu->altmenusu->count()): ?>
                        <ul class="sub-menu">
                            <?php $__currentLoopData = $menu->altmenusu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $altmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if($altmenu->sayfa_id == 0): ?>
                                    <li><a href="<?php echo e($altmenu->ozel_url); ?>"><?php echo e($altmenu->menu_baslik); ?></a></li>
                                    <?php else: ?>
                            <li><a href="/sayfa/<?php echo e($altmenu->sayfa_id); ?>/<?php echo e($altmenu->slug); ?>"><?php echo e($altmenu->menu_baslik); ?></a></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>

                    </li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <li>
                            <a href="<?php echo e(route('duyurular.goster')); ?>">Duyuru ve Etkinlikler</a>
                        </li>
                    <li>
                        <a href="<?php echo e(route('iletisim.formu')); ?>">İletişim</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>

<!-- Header Mobile -->
<nav class="container-header-mobile">
    <div class="wrap-header-mobile">
        <!-- Logo moblie -->
        <div class="logo-mobile">
            <a href="index.html"><img src="/<?php echo e($ayar->logo); ?>" alt="LOGO"></a>
        </div>


        <!-- Button show menu -->
        <div class="btn-show-menu-mobile hamburger hamburger--squeeze">
					<span class="hamburger-box">
						<span class="hamburger-inner"></span>
					</span>
        </div>
    </div>

    <div class="menu-mobile">
        <ul class="top-bar-m p-l-20 p-tb-8">
            <li>
                <div class="t1-s-1 cl-5 p-tb-3">
							<span class="fs-16 m-r-6">
								<i class="fa fa-home" aria-hidden="true"></i>
							</span>
                    <span>379 5Th Ave New York, Nyc 10018</span>
                </div>
            </li>

            <li>
                <div class="t1-s-1 cl-5 p-tb-3">
							<span class="fs-16 m-r-6">
								<i class="fa fa-phone" aria-hidden="true"></i>
							</span>
                    <span>(+1) 96 716 6879</span>
                </div>
            </li>

            <li>
                <div class="t1-s-1 cl-5 p-tb-3">
							<span class="fs-16 m-r-6">
								<i class="fa fa-clock-o" aria-hidden="true"></i>
							</span>
                    <span>Mon-Sat 09:00 am - 17:00 pm/Sunday CLOSE</span>
                </div>
            </li>

            <li>
                <div>
                    <a href="#" class="fs-16 cl-5 hov-link2 trans-02 m-r-15">
                        <i class="fa fa-facebook-official"></i>
                    </a>

                    <a href="#" class="fs-16 cl-5 hov-link2 trans-02 m-r-15">
                        <i class="fa fa-twitter"></i>
                    </a>

                    <a href="#" class="fs-16 cl-5 hov-link2 trans-02 m-r-15">
                        <i class="fa fa-google-plus"></i>
                    </a>

                    <a href="#" class="fs-16 cl-5 hov-link2 trans-02 m-r-15">
                        <i class="fa fa-instagram"></i>
                    </a>

                    <a href="#" class="fs-16 cl-5 hov-link2 trans-02 m-r-15">
                        <i class="fa fa-linkedin"></i>
                    </a>
                </div>
            </li>
        </ul>
    </div>
</nav>
