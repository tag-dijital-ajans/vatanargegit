<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ekip extends Model
{
    protected $table = 'ekip';
    protected $guarded = [];

}
