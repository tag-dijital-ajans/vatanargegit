<?php $__env->startSection('icerik'); ?>


    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5> Sayfa Düzenle : <?php echo e($sayfa->sayfa_basligi); ?></h5>
                </div>



                <div class="widget-content nopadding">
                    <?php echo Form::model($sayfa,(['route'=>['sayfalar.update',$sayfa->id],'method'=>'PUT','class'=>'form-horizontal','files'=>'true'])); ?>





                    <div class="control-group">
                        <label class="control-label"> Sayfa Başlık</label>
                        <div class="controls">
                            <input type="text" class="span11" name="sayfa_basligi" value="<?php echo e($sayfa->sayfa_basligi); ?>"  />
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label"> Sayfa İçerik</label>
                        <div class="controls">
                            <textarea name="sayfa_icerik" class="span11"><?php echo $sayfa->sayfa_icerik; ?></textarea>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label"> Sayfa Kapak Fotoğrafı Ekle </label>
                        <div class="controls">
                            <input type="file" name="sayfa_one_cikan_foto"  class="span11"  />
                        </div>
                        <div><img width="300px" src="/<?php echo e($sayfa->sayfa_one_cikan_foto); ?>"></div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Sayfayı Güncelle</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script src="/adminkurumsal/tinymce/js/tinymce/tinymce.min.js"></script>
    <script>tinymce.init({ selector:'textarea' });</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminkurumsal/template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>