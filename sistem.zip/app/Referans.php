<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Referans extends Model
{
    protected $table = 'referanslar';
    protected $guarded = [];

}
