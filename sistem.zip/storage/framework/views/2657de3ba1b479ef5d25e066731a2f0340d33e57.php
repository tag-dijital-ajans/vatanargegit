<?php $__env->startSection('icerik'); ?>

    <div class="container-fluid">
        <!--Chart-box-->
        <div class="row-fluid">
            <div class="widget-box">
                <div class="widget-title bg_lg"><span class="icon"><i class="icon-signal"></i></span>
                    <h5>Site İstatistik</h5>
                </div>
                <div class="widget-content" >
                    <div class="row-fluid">

                        <div class="span6">
                            <ul class="site-stats">
                                <li class="bg_lr"> <strong><?php echo e($sayfacount); ?></strong> <small>Sayfa</small></li>
                                <li class="bg_lg"> <strong><?php echo e($hizmetcount); ?></strong> <small>Programlar</small></li>
                                <li class="bg_lb"> <strong><?php echo e($habercount); ?></strong> <small>Duyuru ve Etkinlikler</small></li>
                                <li class="bg_ls"> <strong><?php echo e($referanscount); ?></strong> <small>Referans</small></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!--End-Chart-box-->

            <div  class="widget-box">
                <div  class="widget-title bg_lo"  data-toggle="collapse" href="#collapseG3" > <span class="icon icon-paper-clip"> <i class="icon-chevron-down"></i> </span>
                    <h5>  Son Haberler</h5>
                </div>

                <?php $__currentLoopData = $lastnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $haber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="new-update clearfix">
                        <i class="icon-gift"></i>
                        <span class="update-notice">
                        <a title="" href="#"><strong><?php echo e($haber->baslik); ?> </strong></a>
                        <span><?php echo str_limit(strip_tags($haber->icerik ),$limit=200,$end='...'); ?></span> </span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminkurumsal.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>