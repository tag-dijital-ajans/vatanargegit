<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hizmet extends Model
{
    protected $table = 'hizmetler';
    protected $guarded = [];
}
