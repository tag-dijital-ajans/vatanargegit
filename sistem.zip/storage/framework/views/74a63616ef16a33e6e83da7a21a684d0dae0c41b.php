<?php $__env->startSection('icerik'); ?>
<section class="bg-0 p-t-20 p-b-20">
		<div class="container">

			<div class="size-w-1 m-rl-auto">
				<?php echo $anasayfaayar->anasayfametin; ?>

			</div>
		</div>
	</section>

<?php echo $__env->make('anasayfa.services', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>




<!-- Call back -->




<section class="bg-10 p-t-92 p-b-70">
    <div class="container">
        <!-- Title section -->
        <div class="flex-col-c-c p-b-50">
            

           
        </div>

        <!--  -->
        <div class="row justify-content-center">
            <div class="col-sm-10 col-md-6 col-lg-3 p-b-30">
                <!-- Block1 -->
                            <a href="<?php echo e(route('kurumici.form')); ?>"> <img  src="/anasayfa/images/butonlar/kurumicibasvuru.png"></a>
            </div>

            <div class="col-sm-10 col-md-6 col-lg-3 p-b-30">
                <!-- Block1 -->
                <div class="col-sm-10 col-md-6 col-lg-3 p-b-30">
                    <!-- Block1 -->
                    <a href="<?php echo e(route('kurumdisi.form')); ?>"> <img  src="/anasayfa/images/butonlar/kurumdisibasvuru.png"></a>
                </div>
            </div>




        </div>
    </div>
</section>














<!-- News -->
<section class="bg-12 p-t-92 p-b-60">
    <div class="container">
        <!-- Title section -->
        <div class="flex-col-c-c p-b-50">
            <h3 class="t1-b-1 cl-3 txt-center m-b-11">
                Duyuru ve Etkinlikler
            </h3>

            <div class="size-a-2 bg-3"></div>
        </div>

        <!--  -->
        <div class="row justify-content-center">

            <?php $__currentLoopData = $icerikler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icerik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-10 col-md-8 col-lg-4 p-b-40">
                <div class="bg-0 h-full">
                    <a href="/haber/<?php echo e($icerik->id); ?>/<?php echo e($icerik->slug); ?>" class="hov-img0 of-hidden">
                        <img src="/<?php echo e($icerik->resim); ?>" alt="IMG" width="100" height="320">
                    </a>



                    <div class="bg-0 p-rl-28 p-t-26 p-b-35">
                        <h4 class="p-b-12">
                            <a href="/haber/<?php echo e($icerik->id); ?>/<?php echo e($icerik->slug); ?>" class="t1-m-1 cl-3 hov-link2 trans-02">
                                <?php echo e($icerik->baslik); ?>

                            </a>
                        </h4>

                        <div class="flex-wr-s-c p-b-9">
                            <div class="p-r-20">
                                <i class="fs-14 cl-7 fa fa-calendar m-r-2"></i>

                                <span class="t1-s-2 cl-7">
										<?php echo e(date('d-m-y',strtotime($icerik->created_at))); ?>

									</span>
                            </div>

                            
                        </div>

                        <p class="t1-s-2 cl-6 p-b-20">
                            <?php echo $icerik->icerik; ?>

                        </p>

                        <a href="/haber/<?php echo e($icerik->id); ?>/<?php echo e($icerik->slug); ?>"   class="d-inline-flex flex-c-c size-a-1 p-rl-15 t1-s-2 text-uppercase cl-0 bg-11 hov-btn1 trans-02">

                           Daha Fazla Oku...
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>

<?php echo $__env->make('anasayfa.partners', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('anasayfa.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>