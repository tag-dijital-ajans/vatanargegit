<?php $__env->startComponent('mail::layout'); ?>
    
    <?php $__env->slot('header'); ?>
        <?php $__env->startComponent('mail::header', ['url' => config('app.url')]); ?>
            <?php echo e($gonder['siteadi']); ?>

        <?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>

    
    Gönderen: <?php echo e($gonder['name']); ?><br/>
    E-Mail Adresi: <?php echo e($gonder['email']); ?><br/>
    Sicil No: <?php echo e($gonder['sicilno']); ?><br/>
    Telefon: <?php echo e($gonder['phone']); ?><br/>
    Nereden Mezun: <?php echo e($gonder['mezun']); ?><br/>
    Fikir Adı: <?php echo e($gonder['fkrad']); ?><br/>
    Fikir Özeti: <?php echo e($gonder['fkrozet']); ?>


    
    <?php if(isset($subcopy)): ?>
        <?php $__env->slot('subcopy'); ?>
            <?php $__env->startComponent('mail::subcopy'); ?>
                <?php echo e($subcopy); ?>

            <?php echo $__env->renderComponent(); ?>
        <?php $__env->endSlot(); ?>
    <?php endif; ?>

    
    <?php $__env->slot('footer'); ?>
        <?php $__env->startComponent('mail::footer'); ?>
            <?php echo e($gonder['siteadi']); ?>

        <?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>





