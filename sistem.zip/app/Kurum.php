<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kurum extends Model
{
    protected $table = 'kurumlogo';
    protected $guarded = [];
}
