<?php $__env->startSection('icerik'); ?>
<!-- Title page -->
	<section class="bg-img1 kit-overlay1" style="background-image: url(images/bg-05.jpg);">
		<div class="container size-h-3 p-tb-15 flex-col-c-c">
			<h2 class="t1-b-1  cl-0 txt-center m-b-10">
				Proje Ekibi
			</h2>

			<div class="flex-wr-c-c">
				<a href="<?php echo e(route('anasayfa')); ?>" class="breadcrumb-item">
					Anasayfa
				</a>

				<span class="breadcrumb-item">
					Proje Ekibi
				</span>
			</div>
		</div>
	</section>

<!-- Team -->
	<section class="bg-0 p-t-92 p-b-52">
		<div class="container">
			<!-- Title section -->
			

			<!--  -->
			<div class="row justify-content-center">

				<?php $__currentLoopData = $ekipler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ekip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-sm-6 col-md-5 col-lg-3 p-b-40">
					<div>
						<div class="wrap-pic-w pos-relative">
							<img src="/<?php echo e($ekip->fotograf); ?>" alt="IMG">


							<div class="s-full ab-t-l flex-wr-c-c p-tb-30 hov-2">
								<a href="<?php echo e($ekip->twitter); ?>" target="_blank" class="flex-c-c size-a-7 borad-50per bg-0 fs-16 cl-11 hov-btn3 m-all-5 hov-2-1">
									<i class="fa fa-twitter"></i>
								</a>


								<a href="<?php echo e($ekip->linkedin); ?>" target="_blank" class="flex-c-c size-a-7 borad-50per bg-0 fs-16 cl-11 hov-btn3 m-all-5 hov-2-1">
									<i class="fa fa-linkedin"></i>
								</a>


							</div>


						</div>

						<div class="flex-col-c-c p-t-28">
							<a href="#" class="t1-m-1 text-uppercase cl-3 txt-center hov-link2 trans-02 m-b-5">
								<?php echo e($ekip->ad); ?>

							</a>

							<span class="t1-s-5 cl-6 txt-center">
								<?php echo e($ekip->gorev); ?>

							</span>
						</div>
					</div>
				</div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>
		</div>
	</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('anasayfa/template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>