<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sayfa extends Model
{
    protected $table = 'sayfalar';
    protected $guarded = [];
}
